Este es un archivo de asignación
